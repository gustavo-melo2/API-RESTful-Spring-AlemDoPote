package br.com.youngdevs.alemdopoteapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AlemdopoteapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlemdopoteapiApplication.class, args);
	}
	
}
