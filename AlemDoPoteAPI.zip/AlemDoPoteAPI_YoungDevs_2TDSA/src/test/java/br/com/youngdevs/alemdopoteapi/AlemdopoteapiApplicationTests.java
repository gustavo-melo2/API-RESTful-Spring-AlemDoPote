package br.com.youngdevs.alemdopoteapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlemdopoteapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
